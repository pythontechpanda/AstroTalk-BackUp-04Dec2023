from django.db import models

from django.contrib.auth.models import AbstractUser
import os
import datetime
from django.core.validators import MaxValueValidator

# Create your models here.

class User(AbstractUser):
    is_user = models.BooleanField(default=False)

def filepath2(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('profile/', filename)

class UserDetail(models.Model):
    username = models.CharField(max_length=100, unique=True)
    phoneno = models.CharField(max_length=100, unique=True)
    gender = models.CharField(max_length=100)
    dob = models.CharField(max_length=100)
    pob = models.CharField(max_length=100)
    tob = models.CharField(max_length=100)
    profile = models.FileField(upload_to=filepath2, null=True)
    address = models.CharField(max_length=500, null=True)
    
    
class Language(models.Model):
    name = models.CharField(max_length=200, null=True)
    def __str__(self):
        return self.name
    
    
class SelectLanguage(models.Model):
    language = models.JSONField(default=list, null=True)
    user = models.ForeignKey(UserDetail, on_delete=models.CASCADE)
    
    
class CategoryOfProduct(models.Model):
    catprod = models.CharField(max_length=200, null=True)
    active_status = models.BooleanField(default=True)
    
    def __str__(self):
        return self.catprod
        
        
        
def filepath_prod(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('productimg/', filename)

class Products(models.Model):
    prodname = models.CharField(max_length=200, null=True)
    prodpicture = models.ImageField(upload_to=filepath_prod, blank=True, null=True)
    discription = models.CharField(max_length=500, null=True)
    price = models.CharField(max_length=200, null=True)
    quantity = models.CharField(max_length=200, null=True)
    category = models.ForeignKey(CategoryOfProduct, on_delete=models.CASCADE)
    offers = models.CharField(max_length=200, default=0)
    offerprice = models.CharField(max_length=200, default=0)
    active_status = models.BooleanField(default=True)
    
    def __str__(self):
        return self.prodname
        
def filepath_astrologer(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('astrologer/', filename)

class Astrologer(models.Model):
    name = models.CharField(max_length=100, null=True)
    experience = models.CharField(max_length=150, null=True)
    languages = models.CharField(max_length=150, null=True)
    expertise_in = models.CharField(max_length=150, null=True)
    about = models.CharField(max_length=300, null=True)
    contact = models.CharField(max_length=12, null=True)
    price = models.CharField(max_length=200, null=True)
    panditpicture = models.ImageField(upload_to=filepath_astrologer, blank=True, null=True)
            
        
def filepath(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('pujacatimg/', filename)

class CategoryOfPooja(models.Model):
    catname = models.CharField(max_length=200, null=True)
    # catpicture = models.ImageField(upload_to=filepath, blank=True, null=True)
    active_status = models.BooleanField(default=True)
    
    def __str__(self):
        return self.catname
    

class PoojaSlot(models.Model):
    slottime = models.CharField(max_length=10, null=True)
    def __str__(self):
        return self.slottime
    

def filepath_puja(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('pujaimg/', filename)

class Pooja(models.Model):
    name = models.CharField(max_length=200, null=True)
    pojapicture = models.ImageField(upload_to=filepath_puja, blank=True, null=True)
    discription = models.CharField(max_length=2000, null=True)
    needofpuja = models.CharField(max_length=2000, null=True)
    advantages = models.CharField(max_length=2000, null=True)
    pujasamagri = models.CharField(max_length=2000, null=True)
    category = models.ForeignKey(CategoryOfPooja, on_delete=models.CASCADE)
    pujaslot = models.ForeignKey(PoojaSlot, on_delete=models.CASCADE, null=True)
    dateofpuja = models.CharField(max_length=12, null=True)
    price = models.CharField(max_length=200, null=True)
    offers = models.CharField(max_length=200, default=0)
    faq = models.TextField(null=True)
    offerprice = models.CharField(max_length=200, default=0)
    active_status = models.BooleanField(default=True)
    astrologer = models.ForeignKey(Astrologer,on_delete=models.CASCADE, null=True)
    
    def __str__(self):
        return self.name
        
        
def filepath_comm_category(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('comm_category/', filename)

class Category(models.Model):
    catname = models.CharField(max_length=200, null=True)
    catpicture = models.ImageField(upload_to=filepath_comm_category, blank=True, null=True)
    active_status = models.BooleanField(default=True)
    
    def __str__(self):
        return self.catname
        

def filepath_horo(request, filename):
    old_filename = filename
    timeNow = datetime.datetime.now().strftime('%Y%m%d%H:%M:%S')
    filename = "%s%s" % (timeNow, old_filename)
    return os.path.join('horoscop/', filename)
    
class HoroscopeCategory(models.Model):
    catname = models.CharField(max_length=200, null=True)
    horoscopeimg = models.ImageField(upload_to=filepath_horo, blank=True, null=True)
    def __str__(self):
        return self.catname
    
    
class Horoscope(models.Model):
    horscopname = models.ForeignKey(HoroscopeCategory, on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now=True)
    discription = models.CharField(max_length=1000, null=True)
    userid = models.ForeignKey(User,on_delete=models.CASCADE)
    
    def __str__(self):
        return self.horscopname.catname



    
    
    
class KundliMatch(models.Model):
    name = models.CharField(max_length=100)
    birth_date = models.DateField()
    birth_time = models.TimeField()
    birth_place = models.CharField(max_length=100)
    
    
class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.PositiveIntegerField(default=0, validators=[MaxValueValidator(5)])
    created_at = models.DateTimeField(auto_now_add=True)

class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    
    
    
class Order(models.Model):
    prodid = models.ForeignKey(Products,on_delete=models.CASCADE)
    userid = models.ForeignKey(UserDetail,on_delete=models.CASCADE)
    orderdate = models.DateTimeField(auto_now=True)
    order_status = models.BooleanField(default=False)
    quantity = models.CharField(max_length=12, null=True)
    order_price = models.CharField(max_length=200, null=True)
    razor_pay_order_id = models.CharField(max_length=100, null=True, blank=True)
    razor_pay_payment_id = models.CharField(max_length=100, null=True, blank=True)
    razor_pay_payment_signature = models.CharField(max_length=100, null=True, blank=True)
    
    
    
class PujaOrder(models.Model):
    pujaid = models.ForeignKey(Pooja,on_delete=models.CASCADE)
    userid = models.ForeignKey(UserDetail,on_delete=models.CASCADE)
    orderdate = models.DateTimeField(auto_now=True)
    order_status = models.BooleanField(default=False)
    # quantity = models.CharField(max_length=12, null=True)
    order_price = models.CharField(max_length=200, null=True)
    razor_pay_order_id = models.CharField(max_length=100, null=True, blank=True)
    razor_pay_payment_id = models.CharField(max_length=100, null=True, blank=True)
    razor_pay_payment_signature = models.CharField(max_length=100, null=True, blank=True)
    
    

class Cart(models.Model):
    
	class Meta():
		unique_together = ('myuser', 'product')     #using unique together do not create duplicate cart
	quantity = models.CharField(max_length=12, null=True)
	myuser = models.ForeignKey(UserDetail, on_delete=models.CASCADE, null=True)
	product = models.ForeignKey(Products, on_delete=models.CASCADE)
    
    
class CartForWeb(models.Model):
    
	class Meta():
		unique_together = ('user', 'product')     #using unique together do not create duplicate cart
	quantity = models.CharField(max_length=12, null=True)
	user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
	product = models.ForeignKey(Products, on_delete=models.CASCADE)
    

class PujaSlotBook(models.Model):
    
	class Meta():
		unique_together = ('myuser', 'pooja')     #using unique together do not create duplicate cart
  


	myuser = models.ForeignKey(UserDetail, on_delete=models.CASCADE, null=True)
	pooja = models.ForeignKey(Pooja, on_delete=models.CASCADE)
	pujaslot = models.ForeignKey(PoojaSlot, on_delete=models.CASCADE)
	dateofpuja = models.CharField(max_length=12, null=True)
	
	
class PujaSlotBookWeb(models.Model):
    
	class Meta():
		unique_together = ('user', 'pooja')     #using unique together do not create duplicate cart
  

	user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
	pooja = models.ForeignKey(Pooja, on_delete=models.CASCADE)
	pujaslot = models.ForeignKey(PoojaSlot, on_delete=models.CASCADE)
	dateofpuja = models.CharField(max_length=12, null=True)
	
	
	
class Follow(models.Model):
    followed = models.ForeignKey(User, related_name='user_followers', on_delete=models.CASCADE)
    followed_by = models.ForeignKey(User, related_name='user_follows', on_delete=models.CASCADE)
    muted = models.BooleanField(default=False)
    created_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.followed_by.username} started following {self.followed.username}"

        
class PujaReview(models.Model):
    pooja = models.ForeignKey(Pooja,on_delete=models.CASCADE)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    redate = models.DateTimeField(auto_now=True)
    message = models.TextField()
    rating = models.CharField(max_length=6, default=0)
    
    
    
class WalletAdd(models.Model):
    userwallet=models.ForeignKey(User,on_delete=models.CASCADE)
    walletamount=models.IntegerField()
    wallettime=models.DateTimeField(auto_now_add=True)
    walletstatus=models.BooleanField(default=False)
    
    
class WalletAmt(models.Model):
    walt = models.ForeignKey(WalletAdd,on_delete=models.CASCADE)
    userid = models.ForeignKey(User,on_delete=models.CASCADE)
    orderdate = models.DateTimeField(auto_now=True)
    order_status = models.BooleanField(default=False)
    amount = models.CharField(max_length=200, null=True)
    razor_pay_order_id = models.CharField(max_length=100, null=True, blank=True)
    razor_pay_payment_id = models.CharField(max_length=100, null=True, blank=True)
    razor_pay_payment_signature = models.CharField(max_length=100, null=True, blank=True)
    
class PayByWalletAmount(models.Model):
    userid = models.ForeignKey(User,on_delete=models.CASCADE)
    walletid = models.CharField(max_length=100)
    
    

