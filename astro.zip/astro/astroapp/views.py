from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.hashers import make_password
from django.contrib.auth.decorators import login_required

# Create your views here.
def logout_view(request):
    logout(request)
    return render(request,'index.html')

def Index(request):
    if request.user.is_authenticated:
        u=UserDetail.objects.get(username=request.user.username)
        print('u',u.profile)
        return render(request,'index.html', {'pp':u.profile})
    else:
        return render(request,'index.html')
    
@login_required(login_url="/login/")
def About(request):
    return render(request,'about.html')

def Aries(request):
    return render(request,'aries.html')


def BlogCategory(request):
    return render(request,'blog_categories.html')


def BlogDetail(request):
    return render(request,'blog_single.html')

@login_required(login_url="/login/")
def ChineseCategory(request):
    return render(request,'chinese.html')

def ChineseDetail(request):
    return render(request,'chinese_single.html')

def Contact(request):
    return render(request,'contact.html')

def Crystal(request):
    return render(request,'crystal.html')

def KundliDosh(request):
    return render(request,'kundli_dosh.html')

def Numerology(request):
    return render(request,'numerology.html')

def Palm(request):
    return render(request,'palm.html')

def ShopDetail(request):
    return render(request,'shop_single.html')

def ShopCategory(request):
    return render(request,'shop.html')

def TarotDetail(request):
    return render(request,'tarot_single.html')

def TarotCategory(request):
    return render(request,'tarot.html')

def VastuShastra(request):
    return render(request,'vastu_shastra.html')

def UserRegistration(request):
    if request.method == 'POST':
        name = request.POST['name']
        password = request.POST['password']
        username = request.POST['username']
        gender = request.POST['gender']
        email = request.POST['email']
        phoneno = request.POST['phoneno']
        dob = request.POST['dob']
        pob = request.POST['pob']
        tob = request.POST['tob']
        profile = request.FILES['profile']
        address = request.POST['address']

        usr = User(first_name=name,password=make_password(password),username=username,email=email,is_user=True)
        usr.save()

        usrdetail = UserDetail(username=username,gender=gender,
                               phoneno=phoneno,dob=dob,pob=pob,tob=tob,profile=profile,address=address)
        usrdetail.save()

    return render(request,'user_registration.html')

def Login(request):
    if request.method == 'POST':
        name = request.POST['username']
        pwd = request.POST['password']
        usr = authenticate(username=name,password=pwd)
        print("working>>>>>>>>>>>>>>>>>>")
        if usr:
            login(request, usr)
            if usr.is_user:
                u=UserDetail.objects.get(username=usr.username)
                print('u',u.profile)
                return redirect('/')
            else:
                print('no img')
        else:
            return redirect('/userregister/')
    else:
        return render(request, "login.html")

def usereditprofileview(request):
    return render(request,"user_editprofile.html")
    
    
    
    
