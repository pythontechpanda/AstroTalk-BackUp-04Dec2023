from django.urls import path
from . import views

urlpatterns = [
    path('',views.Index),
    path('about/',views.About),
    path('aries/',views.Aries),
    path('blog_categories/',views.BlogCategory),
    path('blog_single/',views.BlogDetail),
    path('chinese/',views.ChineseCategory),
    path('chinese_single/',views.ChineseDetail),
    path('contact/',views.Contact),
    path('crystal/',views.Crystal),
    path('kundli_dosh/',views.KundliDosh),
    path('numerology/',views.Numerology),
    path('palm/',views.Palm),
    path('shop_single/',views.ShopDetail),
    path('shop/',views.ShopCategory),
    path('tarot_single/',views.TarotDetail),
    path('tarot/',views.TarotCategory),
    path('vastu_shastra/',views.VastuShastra),
    path('userregister/',views.UserRegistration),
    path('login/',views.Login),
    path('logout/',views.logout_view),
    path('editprofile/',views.usereditprofileview),
    
]
