from django.urls import path, include
# from rest_framework.routers import DefaultRouter
from . import views

# from django.conf import settings  
# from django.conf.urls.static import static
# from rest_framework.urlpatterns import format_suffix_patterns


# router = DefaultRouter()
# router.register('user-registration', views.UserRegistration, basename='registration'),



urlpatterns=[
    path('login/', views.UserLoginView.as_view(), name='login'),
    path('product-filter/<int:id>', views.ProductFilter),
    path('pooja-filter/<int:id>', views.PoojaFilter),
    path('my-cart/<int:id>',views.CartFilter, name="cart"),
    path('my-puja/<int:id>',views.PoojaFilter, name="puja"),
    path('my-order/<int:id>',views.OrderFilter, name="order"),
    path('my-pujabooked/<int:id>',views.PujaOrderFilter, name="pujabooked"),
    path('followers-filter/<int:id>',views.FollowFilter, name="followers"),
    path('puja-review-filter/<int:id>',views.PujaPujaReviewFilter, name="pujareview"),
]