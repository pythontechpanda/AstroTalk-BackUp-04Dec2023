from rest_framework import serializers
from astroapp.models import *
from .models import *


class Userserializer(serializers.ModelSerializer):
    
    class Meta:
        model = User
        fields = ['first_name', 'username', 'password', 'email', 'is_user']
        
class UserDetailserializer(serializers.ModelSerializer):
    
    class Meta:
        model = UserDetail
        fields = ['id','username', 'phoneno', 'gender', 'dob', 'pob', 'tob', 'profile', 'address']
        
    
class UserInfoserializer(serializers.ModelSerializer):
    
    class Meta:
        model = UserInfo
        fields = ['id','phoneno']
        
class LanguageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Language
        fields = ['id', 'name']
        
        
class Select_LanguageSerializer(serializers.ModelSerializer):
    class Meta:
        model = SelectLanguage
        fields = ['language', 'user']
        # depth = 1
        
        
class CategoryOfProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryOfProduct
        fields = ['id', 'catprod', 'active_status']
        
        
class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = ['id', 'prodname', 'prodpicture', 'discription','price','quantity','category','offers','offerprice','active_status']


class ProductFilterSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    prodname=serializers.CharField(max_length=200)
    prodpicture=serializers.CharField(max_length=200)
    discription=serializers.CharField(max_length=200)
    price=serializers.CharField(max_length=200)
    quantity=serializers.CharField(max_length=200)
    category=serializers.CharField(max_length=200)
    offers=serializers.CharField(max_length=200)
    offerprice=serializers.CharField(max_length=200)
    active_status=serializers.CharField(max_length=200)
    

class AstrologerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Astrologer
        fields = ['id', 'name', 'experience','languages','expertise_in','about','contact','price','panditpicture']

class CategoryOfPoojaSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryOfPooja
        fields = ['id', 'catname', 'active_status']
        
        
class PoojaSlotSerializer(serializers.ModelSerializer):
    class Meta:
        model = PoojaSlot
        fields = ['id', 'slottime']
        

class PoojaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pooja
        fields = ['id', 'name', 'pojapicture', 'discription','needofpuja','advantages','pujasamagri','category','pujaslot','dateofpuja','price','offers','offerprice','faq','active_status','astrologer']


class PoojaGetSerializer(serializers.ModelSerializer):
    astrologer=AstrologerSerializer(read_only=True)
    category=CategoryOfPoojaSerializer(read_only=True)
    class Meta:
        model = Pooja
        fields = ['id', 'name', 'pojapicture', 'discription','needofpuja','advantages','pujasamagri','category','pujaslot','dateofpuja','price','offers','offerprice','faq','active_status','astrologer']
        
        
class PoojaFilterSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    name=serializers.CharField(max_length=200)
    pojapicture=serializers.CharField(max_length=200)
    discription=serializers.CharField(max_length=200)
    needofpuja=serializers.CharField(max_length=200)
    advantages=serializers.CharField(max_length=200)
    pujasamagri=serializers.CharField(max_length=200)
    category=serializers.CharField(max_length=200)
    price=serializers.CharField(max_length=200)
    offers=serializers.CharField(max_length=200)
    offerprice=serializers.CharField(max_length=200)
    active_status=serializers.CharField(max_length=200)
    
class HoroscopeCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = HoroscopeCategory
        fields = ['id', 'catname', 'horoscopeimg']
        
        
class HoroscopeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Horoscope
        fields = ['id', 'horscopname', 'date','discription','userid']
        
        
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'catname', 'catpicture','active_status']
        

        
        
        
class KundliMatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = KundliMatch
        fields = ['id', 'name', 'birth_date', 'birth_time', 'birth_place']
        
class RatingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rating
        fields = '__all__'

class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        fields = '__all__'
        
        
        
class CartSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cart
        fields = ['id', 'myuser', 'quantity', 'product']
        
class CartFilterSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    user=serializers.CharField(max_length=200)
    quantity=serializers.CharField(max_length=200)
    product=serializers.CharField(max_length=200)
    price=serializers.CharField(max_length=200)
        
        
class PujaSlotBookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = PujaSlotBook
        fields = ['id', 'myuser', 'pooja', 'pujaslot', 'dateofpuja']  
        

class PujaFilterSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    user=serializers.CharField(max_length=200)
    pooja=serializers.CharField(max_length=200)
    pujaslot=serializers.CharField(max_length=200)
    dateofpuja=serializers.CharField(max_length=200) 
    price=serializers.CharField(max_length=200)
        
class ProductOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['id', 'prodid', 'userid', 'orderdate', 'order_status','quantity','order_price','razor_pay_order_id','razor_pay_payment_signature']
        

class OrderSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    prodid=serializers.CharField(max_length=200)
    userid=serializers.CharField(max_length=200)
    orderdate=serializers.CharField(max_length=200)
    order_status=serializers.CharField(max_length=200) 
    quantity=serializers.CharField(max_length=200) 
    order_price=serializers.CharField(max_length=200) 
    razor_pay_order_id=serializers.CharField(max_length=200) 
    razor_pay_payment_signature=serializers.CharField(max_length=200) 
        
        
class PoojaOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = PujaOrder
        fields = ['id', 'pujaid', 'userid','order_status', 'orderdate','order_price','razor_pay_order_id','razor_pay_payment_signature']
        
        

class PujaOrderFilterSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    pujaid=serializers.CharField(max_length=200)
    userid=serializers.CharField(max_length=200)
    order_date=serializers.CharField(max_length=200)
    order_status=serializers.CharField(max_length=200)  
    order_price=serializers.CharField(max_length=200) 
    razor_pay_order_id=serializers.CharField(max_length=200) 
    razor_pay_payment_signature=serializers.CharField(max_length=200)
    
    

class FollowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Follow
        fields = ['id', 'followed', 'followed_by', 'muted', 'created_date']
        
        
class PujaReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = PujaReview
        fields = ['id', 'pooja', 'user', 'redate', 'message', 'rating']
        
        
        
class PujaReviewFilterSerializer(serializers.Serializer):
    id=serializers.CharField(max_length=200)
    pooja=serializers.CharField(max_length=200)
    user=serializers.CharField(max_length=200)
    redate=serializers.CharField(max_length=200)
    message=serializers.CharField(max_length=200)  
    rating=serializers.CharField(max_length=200) 
        
        
        
class WalletAddSerializer(serializers.ModelSerializer):
    class Meta:
        model = WalletAdd
        fields = ['id', 'userwallet', 'walletamount', 'wallettime', 'walletstatus']
        
class WalletAmtSerializer(serializers.ModelSerializer):
    class Meta:
        model = WalletAmt
        fields = ['id', 'walt', 'userid', 'orderdate', 'order_status', 'amount', 'razor_pay_order_id','razor_pay_payment_id', 'razor_pay_payment_signature']
        
        
class PayByWalletAmountSerializer(serializers.ModelSerializer):
    class Meta:
        model = PayByWalletAmount
        fields = ['id', 'userid', 'walletid']
        
        