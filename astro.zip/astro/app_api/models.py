from django.db import models

# Create your models here.
# Create your models here.
class UserInfo(models.Model):
    phoneno=models.CharField(max_length=100)
    