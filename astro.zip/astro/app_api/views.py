from django.shortcuts import render
from astroapp.models import *
from .serializers import *
from django.contrib.auth import authenticate
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from .models import *
import random
import razorpay
from astro import settings

# Create your views here.


class UserRegistration(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = User.objects.all()
        serializer = Userserializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = User.objects.get(id=id)
            serializer = Userserializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = Userserializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = User.objects.get(pk=id)
        serializer = Userserializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = User.objects.get(pk=id)
        serializer = Userserializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='profile':
                    stu.upload = request.FILES['profile']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = User.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})






class UserDetailRegistration(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = UserDetail.objects.all()
        serializer = UserDetailserializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = UserDetail.objects.get(id=id)
            serializer = UserDetailserializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = UserDetailserializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            var =serializer.data['id']
            return Response({'msg': 'Data Created','userid':var}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = UserDetail.objects.get(pk=id)
        serializer = UserDetailserializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = UserDetail.objects.get(pk=id)
        serializer = UserDetailserializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='profile':
                    stu.upload = request.FILES['profile']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = UserDetail.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class UserLoginView(APIView):
    
    def post(self, request, format=None):
        print('postttttt')
        phoneno = request.data['phoneno']
        password = request.data['password']
        user=UserDetail.objects.filter(phoneno=phoneno)
        pas = User.objects.filter(password=password)
        
        print(user)
        print('poeytj')
        if user and pas:
            # user_verify = UserDetail.objects.filter(phoneno=phoneno)
            # pas_verify = User.objects.filter(password=password)
            # # print('fdhv',user_verify)username
            # if user_verify and pas_verify:
            return Response( {'msg': 'Login Success','id':user[0].id}, status=status.HTTP_200_OK)
        else:
            return Response({'errors': 'Phone number or password is not valid and please Enter correct info.'})
 
class UserInfoRegistration(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = UserInfo.objects.all()
        serializer = UserInfoserializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = UserInfo.objects.get(id=id)
            serializer = UserInfoserializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = UserInfoserializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            phone_id = serializer.data['id']
            u=UserDetail.objects.filter(phoneno=serializer.data['phoneno'])
            
            global i 
            for i in u:                
                i=i.id
                
            if u:
                otp = str(random.randint(1000, 9999))
                print(otp)
                return Response({'msg': 'Data Created','id':phone_id,'otp':otp ,'phoneno':'Existing','user':i}, status= status.HTTP_201_CREATED)
            else:
                otp = str(random.randint(1000, 9999))
                print(otp)
                return Response({'msg': 'Data Created','id':phone_id,'otp':otp ,'phoneno':'New'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = UserInfo.objects.get(pk=id)
        serializer = UserInfoserializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = UserInfo.objects.get(pk=id)
        serializer = UserInfoserializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='profile':
                    stu.upload = request.FILES['profile']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = UserInfo.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class LanguageView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Language.objects.all()
        serializer = LanguageSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Language.objects.get(id=id)
            serializer = LanguageSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = LanguageSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Language.objects.get(pk=id)
        serializer = LanguageSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Language.objects.get(pk=id)
        serializer = LanguageSerializer(stu, data=request.data, partial=True)
       
        serializer.save()
        return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Language.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})

     

class SelectLanguageView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = SelectLanguage.objects.all()
        serializer = Select_LanguageSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = SelectLanguage.objects.get(id=id)
            serializer = Select_LanguageSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = Select_LanguageSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = SelectLanguage.objects.get(pk=id)
        serializer = Select_LanguageSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = SelectLanguage.objects.get(pk=id)
        serializer = Select_LanguageSerializer(stu, data=request.data, partial=True)
       
        serializer.save()
        return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = SelectLanguage.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})






class CategoryOfProductView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = CategoryOfProduct.objects.all()
        serializer = CategoryOfProductSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = CategoryOfProduct.objects.get(id=id)
            serializer = CategoryOfProductSerializer(stu)
            return Response(serializer.data)
            
            
    def create(self, request):
        serializer = CategoryOfProductSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = CategoryOfProduct.objects.get(pk=id)
        serializer = CategoryOfProductSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = CategoryOfProduct.objects.get(pk=id)
        serializer = CategoryOfProductSerializer(stu, data=request.data, partial=True)
       
        serializer.save()
        return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = CategoryOfProduct.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class ProductsView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Products.objects.all()
        serializer = ProductSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Products.objects.get(id=id)
            serializer = ProductSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = ProductSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Products.objects.get(pk=id)
        serializer = ProductSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Products.objects.get(pk=id)
        serializer = ProductSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='prodpicture':
                    stu.upload = request.FILES['prodpicture']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Products.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})




@api_view(['GET'])
def ProductFilter(request,id=None, format=None):
    try:
        if request.method == 'GET':
            print('currentuser.',id)
            # currentuser=user.id
            cate = CategoryOfProduct.objects.get(id=id)
            
            get_objs=Products.objects.filter(category=cate)
            l=[]
            # l2 =[]
            if get_objs[0].category==cate:
                for i in get_objs:
                    d={}         
                    
                    d.update({'id':i.id,'prodname':i.prodname,'prodpicture':i.prodpicture, 'discription':i.discription,'price':i.price,'quantity':i.quantity,'category':i.category.catprod,'offers':i.offers, 'offerprice':i.offerprice,'active_status':i.active_status})
                    l.append(d)
                print(l)
            
                    
                results = ProductFilterSerializer(l, many=True).data
            else:
                results=0
                
            return Response({'results':results})
    except:
        return Response("No data found")


class CategoryOfPoojaView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = CategoryOfPooja.objects.all()
        serializer = CategoryOfPoojaSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = CategoryOfPooja.objects.get(id=id)
            serializer = CategoryOfPoojaSerializer(stu)
            return Response(serializer.data)
        
        
    def create(self, request):
        serializer = CategoryOfPoojaSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = CategoryOfPooja.objects.get(pk=id)
        serializer = CategoryOfPoojaSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = CategoryOfPooja.objects.get(pk=id)
        serializer = CategoryOfPoojaSerializer(stu, data=request.data, partial=True)
       
        serializer.save()
        return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = CategoryOfPooja.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
        
        
        

class PoojaSlotView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = PoojaSlot.objects.all()
        serializer = PoojaSlotSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = PoojaSlot.objects.get(id=id)
            serializer = PoojaSlotSerializer(stu)
            return Response(serializer.data)
            
    def create(self, request):
        serializer = PoojaSlotSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class PoojaView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Pooja.objects.all()
        serializer = PoojaGetSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Pooja.objects.get(id=id)
            serializer = PoojaGetSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = PoojaSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Pooja.objects.get(pk=id)
        serializer = PoojaSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Pooja.objects.get(pk=id)
        serializer = PoojaSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='pojapicture':
                    stu.upload = request.FILES['pojapicture']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Pooja.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
        
        
        
        
@api_view(['GET'])
def PoojaFilter(request,id=None, format=None):
    try:
        if request.method == 'GET':
            print('currentuser.',id)
            # currentuser=user.id
            cate = CategoryOfPooja.objects.get(id=id)
            
            get_objs=Pooja.objects.filter(category=cate)
            # for i in get_objs:
            #     print(i)
            l=[]
            # l2 =[]
            if get_objs[0].category==cate:
                for i in get_objs:
                    # print('rrrrrrrrrrrrrrrrr')
                    d={}         
                    
                    d.update({'id':i.id,'name':i.name,'pojapicture':i.pojapicture,'discription':i.discription,'needofpuja':i.needofpuja,'advantages':i.advantages,'pujasamagri':i.pujasamagri,'price':i.price,'category':i.category.catname,'offers':i.offers,'offerprice':i.offerprice,'active_status':i.active_status})
                    l.append(d)
                print(l)
            
                    
                results = PoojaFilterSerializer(l, many=True).data
                print(">>>>>>>>>>>>>>",results)
            else:
                results=0
                
            return Response({'results':results})
    except:
        return Response("No data found")




class HoroscopeCategoryView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = HoroscopeCategory.objects.all()
        serializer = HoroscopeCategorySerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = HoroscopeCategory.objects.get(id=id)
            serializer = HoroscopeCategorySerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = HoroscopeCategorySerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = HoroscopeCategory.objects.get(pk=id)
        serializer = HoroscopeCategorySerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = HoroscopeCategory.objects.get(pk=id)
        serializer = HoroscopeCategorySerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='horoscopeimg':
                    stu.upload = request.FILES['horoscopeimg']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = HoroscopeCategory.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class HoroscopeView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Horoscope.objects.all()
        serializer = HoroscopeSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Horoscope.objects.get(id=id)
            serializer = HoroscopeSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = HoroscopeSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Horoscope.objects.get(pk=id)
        serializer = HoroscopeSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Horoscope.objects.get(pk=id)
        serializer = HoroscopeSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='horoscopeimg':
                    stu.upload = request.FILES['horoscopeimg']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Horoscope.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})


class CategoryView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Category.objects.all()
        serializer = CategorySerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Category.objects.get(id=id)
            serializer = CategorySerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = CategorySerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Category.objects.get(pk=id)
        serializer = CategorySerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Category.objects.get(pk=id)
        serializer = CategorySerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='catpicture':
                    stu.upload = request.FILES['catpicture']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Category.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class AstrologerView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Astrologer.objects.all()
        serializer = AstrologerSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Astrologer.objects.get(id=id)
            serializer = AstrologerSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = AstrologerSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Astrologer.objects.get(pk=id)
        serializer = AstrologerSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Astrologer.objects.get(pk=id)
        serializer = AstrologerSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            if len(request.FILES) !=0:
                if request.data=='panditpicture':
                    stu.upload = request.FILES['panditpicture']
                stu.save()
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Astrologer.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})




class KundliMatchView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = KundliMatch.objects.all()
        serializer = KundliMatchSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = KundliMatch.objects.get(id=id)
            serializer = KundliMatchSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = KundliMatchSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = KundliMatch.objects.get(pk=id)
        serializer = KundliMatchSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = KundliMatch.objects.get(pk=id)
        serializer = KundliMatchSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = KundliMatch.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class RatingView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Rating.objects.all()
        serializer = RatingSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Rating.objects.get(id=id)
            serializer = RatingSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = RatingSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Rating.objects.get(pk=id)
        serializer = RatingSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Rating.objects.get(pk=id)
        serializer = RatingSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Rating.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})


class FeedbackView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Feedback.objects.all()
        serializer = FeedbackSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Feedback.objects.get(id=id)
            serializer = FeedbackSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = FeedbackSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Feedback.objects.get(pk=id)
        serializer = FeedbackSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Feedback.objects.get(pk=id)
        serializer = FeedbackSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Feedback.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
        
        
        
class ProductOrderView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Order.objects.all()
        serializer = ProductOrderSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Order.objects.get(id=id)
            serializer = ProductOrderSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = ProductOrderSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Order.objects.get(pk=id)
        serializer = ProductOrderSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Order.objects.get(pk=id)
        serializer = ProductOrderSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Order.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
    
    
    
class PoojaOrderView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = PujaOrder.objects.all()
        serializer = PoojaOrderSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = PujaOrder.objects.get(id=id)
            serializer = PoojaOrderSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = PoojaOrderSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = PujaOrder.objects.get(pk=id)
        serializer = PoojaOrderSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = PujaOrder.objects.get(pk=id)
        serializer = PoojaOrderSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = PujaOrder.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
    
    
    
class CartView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Cart.objects.all()
        serializer = CartSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Cart.objects.get(id=id)
            serializer = CartSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = CartSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Cart.objects.get(pk=id)
        serializer = CartSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Cart.objects.get(pk=id)
        serializer = CartSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Cart.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})



class PujaSlotBookingView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = PujaSlotBook.objects.all()
        serializer = PujaSlotBookingSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = PujaSlotBook.objects.get(id=id)
            serializer = PujaSlotBookingSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = PujaSlotBookingSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            client = razorpay.Client(auth = (settings.razor_pay_key_id, settings.key_secret) )
            print(">>>>>>", client)
            payment = client.order.create({ 'amount': 100, 'currency': 'INR', 'payment_capture': 1})
            return Response({'msg': 'Data Created', 'id':serializer.data['id'], 'user':serializer.data['myuser'], 'pooja':serializer.data['pooja'],'order_id':payment['id']}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = PujaSlotBook.objects.get(pk=id)
        serializer = PujaSlotBookingSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = PujaSlotBook.objects.get(pk=id)
        serializer = PujaSlotBookingSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = PujaSlotBook.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
        
        
        
@api_view(['GET'])
def CartFilter(request,id=None, format=None):
    try:
        c = 0
        if request.method == 'GET':
            print('currentuser.',id)
            # currentuser=user.id
            usr = User.objects.get(id=id)
            
            get_objs=Cart.objects.filter(user=usr)
            for i in get_objs:
                print(i)
            l=[]
            l2 =[]
            
            if get_objs[0].user==usr:
                for i in get_objs:
                    # print('rrrrrrrrrrrrrrrrr')
                    
                    d={}         
                    
                    price = int(i.product.price)
                    qty = int(i.quantity)
                    total =price*qty
                    c += total
                    d.update({'id':i.id,'user':i.user,'quantity':i.quantity,'product':i.product,'price':total})
                    l.append(d)
                print(l)
                # var =
                    
                results = CartFilterSerializer(l, many=True).data
                print(">>>>>>>>>>>>>>",results)
            else:
                results=0
                
            return Response({'results':results,'totalamount':c})
    except:
        return Response("No data found")
        
        
@api_view(['GET'])
def PoojaFilter(request,id=None, format=None):
    try:
        c = 0
        if request.method == 'GET':
            print('currentuser.',id)
            usr = User.objects.get(id=id)
            
            get_objs=PujaSlotBook.objects.filter(user=usr)
            print(get_objs)
            for i in get_objs:
                print(i)
            l=[]
            l2 =[]
            
            if get_objs[0].user==usr:
                for i in get_objs:                    
                    d={}         
                    
                    price = int(i.pooja.price)                    
                    c +=price
                    d.update({'id':i.id,'user':i.user,'pooja':i.pooja,'price':i.pooja.price,'pujaslot':i.pujaslot,'dateofpuja':i.dateofpuja})
                    l.append(d)
                print(l)
                    
                results = PujaFilterSerializer(l, many=True).data
                print(">>>>>>>>>>>>>>",results)
            else:
                results=0                
            return Response({'results':results,'totalamount':c})
    except:
        return Response("No data found")


@api_view(['GET'])
def OrderFilter(request,id=None, format=None):
    try:
        if request.method == 'GET':
            print('currentuser.',id)
            usr = User.objects.get(id=id)
            
            get_objs=Order.objects.filter(userid=usr)
            print("<>><><><>><><><><><>",get_objs[0])
            for i in get_objs:
                print(i)
            l=[]
        
            
            if get_objs[0].userid==usr:
                for i in get_objs:                    
                    d={}         
                    
                    d.update({'id':i.id,'prodid':i.prodid,'userid':i.userid,'orderdate':i.orderdate,'order_status':i.order_status,'quantity':i.quantity,'order_price':i.order_price,'razor_pay_order_id':i.razor_pay_order_id,'razor_pay_payment_signature':i.razor_pay_payment_signature})
                    l.append(d)
                print(l)
                    
                results = OrderSerializer(l, many=True).data
                print(">>>>>>>>>>>>>>",results)
            else:
                results=0                
            return Response({'results':results})
    except:
        return Response("No data found")
        

@api_view(['GET'])
def PujaOrderFilter(request,id=None, format=None):
    try:
        if request.method == 'GET':
            print('currentuser.',id)
            usr = User.objects.get(id=id)
            
            get_objs=PujaOrder.objects.filter(userid=usr)
            print("<>><><><>><><><><><>",get_objs[0])
            for i in get_objs:
                print(i)
            l=[]
        
            
            if get_objs[0].userid==usr:
                for i in get_objs:                    
                    d={}         
                    
                    d.update({'id':i.id,'pujaid':i.pujaid,'userid':i.userid,'order_date':i.orderdate,'order_status':i.order_status,'order_price':i.order_price,'razor_pay_order_id':i.razor_pay_order_id,'razor_pay_payment_signature':i.razor_pay_payment_signature})
                    l.append(d)
                print(l)
                    
                results = PujaOrderFilterSerializer(l, many=True).data
                print(">>>>>>>>>>>>>>",results)
            else:
                results=0                
            return Response({'results':results})
    except:
        return Response("No data found")
        
        
        
class FollowView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = Follow.objects.all()
        serializer = FollowSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = Follow.objects.get(id=id)
            serializer = FollowSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = FollowSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = Follow.objects.get(pk=id)
        serializer = FollowSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = Follow.objects.get(pk=id)
        serializer = FollowSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = Follow.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
    
    
    
    
@api_view(['GET'])
def FollowFilter(request,id=None, format=None):
    try:
        if request.method == 'GET':
            print('currentuser.',id)
            usr = User.objects.get(id=id)
            
            get_objs=Follow.objects.filter(followed=usr).count()
            # print("<>><><><>><><><><><>",get_objs)   
                      
            return Response({'no_fo_followers':get_objs})
    except:
        return Response("No data found")
    
    
    
    
class PujaReviewView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = PujaReview.objects.all()
        serializer = PujaReviewSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = PujaReview.objects.get(id=id)
            serializer = PujaReviewSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = PujaReviewSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = PujaReview.objects.get(pk=id)
        serializer = PujaReviewSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = PujaReview.objects.get(pk=id)
        serializer = PujaReviewSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = PujaReview.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
        
        
@api_view(['GET'])
def PujaPujaReviewFilter(request,id=None, format=None):
    try:
        if request.method == 'GET':
            print('currentuser.',id)
            usr = Pooja.objects.get(id=id)
            
            get_objs=PujaReview.objects.filter(pooja=usr)
            print("<>><><><>><><><><><>",get_objs[0])
            for i in get_objs:
                print(i)
            l=[]
        
            
            if get_objs[0].pooja==usr:
                for i in get_objs:                    
                    d={}         
                    
                    d.update({'id':i.id,'pooja':i.pooja,'user':i.user,'redate':i.redate,'message':i.message,'rating':i.rating})
                    l.append(d)
                print(l)
                    
                results = PujaReviewFilterSerializer(l, many=True).data
                print(">>>>>>>>>>>>>>",results)
            else:
                results=0                
            return Response({'results':results})
    except:
        return Response("No data found")
        


class WalletAddView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = WalletAdd.objects.all()
        serializer = WalletAddSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = WalletAdd.objects.get(id=id)
            serializer = WalletAddSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = WalletAddSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = WalletAdd.objects.get(pk=id)
        serializer = WalletAddSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = WalletAdd.objects.get(pk=id)
        serializer = WalletAddSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = WalletAdd.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
    
    
    
class WalletAmtView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = WalletAmt.objects.all()
        serializer = WalletAmtSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = WalletAmt.objects.get(id=id)
            serializer = WalletAmtSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = WalletAmtSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = WalletAmt.objects.get(pk=id)
        serializer = WalletAmtSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = WalletAmt.objects.get(pk=id)
        serializer = WalletAmtSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = WalletAmt.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
    
    
class PayByWalletAmountView(viewsets.ViewSet):
    def list(self, request):      # list - get all record
        stu = PayByWalletAmount.objects.all()
        serializer = PayByWalletAmountSerializer(stu, many=True)    # many use for bulk data come 
        return Response(serializer.data)


    def retrieve(self, request, pk=None):
        id = pk
        if id is not None:
            stu = PayByWalletAmount.objects.get(id=id)
            serializer = PayByWalletAmountSerializer(stu)
            return Response(serializer.data)

    def create(self, request):
        serializer = PayByWalletAmountSerializer(data = request.data)  # form data conviert in json data
        if serializer.is_valid():
            serializer.save()
            print(serializer.data)
            return Response({'msg': 'Data Created'}, status= status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def update(self, request, pk):
        id = pk
        stu = PayByWalletAmount.objects.get(pk=id)
        serializer = PayByWalletAmountSerializer(stu, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Complete Data Update'})
        return Response(serializer.errors)

    def partial_update(self, request, pk):
        id = pk
        stu = PayByWalletAmount.objects.get(pk=id)
        serializer = PayByWalletAmountSerializer(stu, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'msg': 'Partial Data Update'})
        return Response(serializer.errors)

    def destroy(self, request, pk):
        id = pk
        stu = PayByWalletAmount.objects.get(pk=id)
        stu.delete()
        return Response({'msg': 'Data deleted'})
    

