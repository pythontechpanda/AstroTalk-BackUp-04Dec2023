"""
URL configuration for astro project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings 
from rest_framework.routers import DefaultRouter
from app_api import views
from django.conf.urls.static import static
from rest_framework.urlpatterns import format_suffix_patterns


router = DefaultRouter()
router.register('user-registration', views.UserRegistration, basename='registration'),
router.register('user-detail', views.UserDetailRegistration, basename='details'),
router.register('user-login', views.UserInfoRegistration, basename='login'),
router.register('language', views.SelectLanguageView, basename="select-language")
router.register('product-category', views.CategoryOfProductView, basename="prod-cat")
router.register('product', views.ProductsView, basename="prod")
router.register('puja-category', views.CategoryOfPoojaView, basename="puja-cat")
router.register('puja-slot', views.PoojaSlotView, basename="slot")
router.register('puja', views.PoojaView, basename="puja")
router.register('horoscope-category', views.HoroscopeCategoryView, basename="horo-cat")
router.register('Horoscope', views.HoroscopeView, basename="horo")
router.register('base-category', views.CategoryView, basename="category")
router.register('language-add', views.LanguageView, basename="language")
router.register('astrologer', views.AstrologerView, basename="astrologer")
router.register('kundli-match', views.KundliMatchView, basename='kundli'),
router.register('rating', views.RatingView, basename='rating'),
router.register('feedback', views.FeedbackView, basename='feedback'),
router.register('cart', views.CartView, basename='mycart'),
router.register('puja-slot-booking', views.PujaSlotBookingView, basename='puja-slot'),

router.register('produsct-order', views.ProductOrderView, basename='prod-order'),
router.register('pujaorder', views.PoojaOrderView, basename='poojaorder')

router.register('follow', views.FollowView, basename='follow'),
router.register('puja-review', views.PujaReviewView, basename='review'),

router.register('wallet-add', views.WalletAddView, basename='add-amount'),
router.register('wallet-amount', views.WalletAmtView, basename='amount'),
router.register('pay-by', views.PayByWalletAmountView, basename='payby'),

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('astroapp.urls')),
    
    path('base/', include(router.urls)),
    path('api/', include('app_api.urls'))
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)